"use strict";
window.print();
