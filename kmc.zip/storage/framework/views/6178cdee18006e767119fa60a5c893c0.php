<!-- Footer -->
<footer class="content-footer footer bg-footer-theme">
    <div class="container-xxl">
        <div class="footer-container d-flex align-items-center justify-content-between py-4 flex-md-row flex-column">
            <div class="text-body">
                ©
                <script>
                    document.write(new Date().getFullYear());
                </script>
                , made with ❤️ by <a href="https://aritechbd.com/" target="_blank" class="footer-link">Aritechbd</a>
            </div>
            <div class="d-none d-lg-inline-block">
                <a href="#" class="footer-link me-4" target="_blank">License</a>
                <a href="#" target="_blank" class="footer-link me-4">More Themes</a>

                <a href="#" target="_blank" class="footer-link me-4">Documentation</a>

                <a href="#" target="_blank" class="footer-link d-none d-sm-inline-block">Support</a>
            </div>
        </div>
    </div>
</footer>
<!-- / Footer -->
<?php /**PATH D:\Dipankar\laravel vue\kmc\resources\views/backend/layouts/footer.blade.php ENDPATH**/ ?>